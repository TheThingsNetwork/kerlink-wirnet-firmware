#!/bin/sh
# Remove custom binaries from firmware to avoid misunderstandings.

echo "Removing custom Semtech tests binaries"
rm -f usr/local/bin/loragw* usr/local/bin/test_loragw*

DEMO_PKTFWD_TEST_REF_FILE="manifest.xml"
#backup old version
PKT_FWD_DIR=`find ./ -name $DEMO_PKTFWD_TEST_REF_FILE -type f | awk -F\/ '{print $4}'`

cd ./mnt/fsuser-1

for i in $PKT_FWD_DIR
do
  tar -czvf backup_$i_`date +%s`.tar.gz $i
  rm -rf $i
done

rm -rf /mnt/fsuser-1/demo_gps_loramote
