#!/bin/sh
BASE="/mnt/fsuser-1/thethingsnetwork"
cd ${BASE}
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/usr/lib"
killall poly_pkt_fwd
modem_off.sh
sleep 3
modem_on.sh
sleep 3
./poly_pkt_fwd > poly_pkt_fwd.log
