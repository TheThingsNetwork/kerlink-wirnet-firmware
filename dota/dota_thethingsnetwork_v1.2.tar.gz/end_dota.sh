#!/bin/sh

MAC_ADDR_COMMON="024b08"
KNET_ID=$(get_uvar ethaddr | awk -F\: '{print tolower($4$5$6)}')
MAC_ADDR=${MAC_ADDR_COMMON}${KNET_ID}

# customize the json file with gateway MAC address

echo "{"                                              > ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "  \"gateway_conf\": {"                         >> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "      \"gateway_ID\": \"0000${MAC_ADDR}\","    >> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "      \"serv_port_up\": 1700,"			>> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "      \"serv_port_down\": 1700,"			>> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "      \"server_address\": \"staging.thethingsnetwork.org\"," >> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "      \"forward_crc_valid\": true,"			>> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "      \"forward_crc_error\": true,"			>> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "      \"forward_crc_disabled\": true"			>> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "  }"                                           >> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
echo "}"                                             >> ./mnt/fsuser-1/demo_gps_loramote/local_conf.json
